=============
Installation
=============

1. Mount the PXIe acquisition module(s) in the chassis.
2. Log in with an account that has administrative privileges and open Device Manager.
3. If Enclustra drivers are already installed, uninstall them before upgrading:
    a. Right-click each Enclustra PCI Express Adapter entry.
    b. Select Uninstall device.
    c. If Windows offers a checkbox to delete the driver software, enable it.
    d. Repeat this process for every Enclustra entry in the system, one per Imec basestation card.
    e. Confirm that each device now appears under Other devices as PCI Memory Controller. If it does not, select Action > Scan for hardware changes in Device Manager.
4. Install the driver only for entries listed as PCI Memory Controller:
    a. Right-click PCI Memory Controller and select Update driver.
    b. Choose Browse my computer for driver software.
    c. Browse to the folder containing the extracted Enclustra driver files and click Next.
    d. Wait for Windows to report that the driver update completed successfully, then close the dialog.
    e. Repeat these steps for each PXIe acquisition module in the chassis.
4. Reboot the PC and log back in.
6. Re-open Device Manager and verify that the hardware now appears under Enclustra Devices as Enclustra PCI Express Adapter.

Done.